/* ==========================================================================
   VIDA SAUDÁVEL ANGOLA — artigos-dados.js
   Registo central dos artigos do blog. Cada lote de artigos novos deve
   adicionar um objeto a este array. O blog/index.html lê este ficheiro
   para gerar a listagem, a pesquisa e os filtros por categoria.
   ========================================================================== */
window.ARTIGOS_VSA = [
  {
    titulo: "Como montar um prato equilibrado no dia a dia em Angola",
    resumo: "Aprenda a montar um prato equilibrado com alimentos comuns em Angola, sem complicações e sem gastar mais do que já gasta.",
    categoria: "alimentacao",
    categoriaNome: "Alimentação",
    url: "prato-equilibrado-dia-a-dia-angola.html",
    tempoLeitura: "9 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Alimentos angolanos ricos em nutrientes que deve conhecer",
    resumo: "Conheça alimentos tradicionais angolanos ricos em vitaminas, minerais e fibra, e como incluí-los mais vezes na sua alimentação.",
    categoria: "alimentacao",
    categoriaNome: "Alimentação",
    url: "alimentos-angolanos-ricos-em-nutrientes.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Como reduzir o açúcar na alimentação sem sofrimento",
    resumo: "Dicas práticas e graduais para reduzir o consumo de açúcar no dia a dia, sem cortes drásticos nem sensação de privação.",
    categoria: "alimentacao",
    categoriaNome: "Alimentação",
    url: "como-reduzir-o-acucar-na-alimentacao-sem-sofrimento.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Guia de compras saudáveis com orçamento limitado",
    resumo: "Como fazer compras nutritivas no mercado ou supermercado sem gastar mais, aproveitando alimentos acessíveis e da época.",
    categoria: "alimentacao",
    categoriaNome: "Alimentação",
    url: "compras-saudaveis-orcamento-limitado.html",
    tempoLeitura: "9 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Receita de funge nutritivo com feijão e legumes",
    resumo: "Receita simples de funge acompanhado de feijão e legumes, uma refeição completa e acessível para o dia a dia.",
    categoria: "receitas",
    categoriaNome: "Receitas",
    url: "funge-nutritivo-com-feijao-e-legumes.html",
    tempoLeitura: "7 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Muamba de galinha mais leve: como preparar",
    resumo: "Uma versão mais leve da tradicional muamba de galinha, mantendo o sabor e reduzindo o excesso de óleo.",
    categoria: "receitas",
    categoriaNome: "Receitas",
    url: "muamba-de-galinha-mais-leve.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Smoothie de banana e abacate para ganhar peso saudável",
    resumo: "Receita de smoothie calórico e nutritivo com banana e abacate, ideal para quem quer ganhar peso de forma saudável.",
    categoria: "receitas",
    categoriaNome: "Receitas",
    url: "smoothie-banana-abacate-ganhar-peso.html",
    tempoLeitura: "6 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Salada de quiabo e tomate: receita fresca e leve",
    resumo: "Receita simples e refrescante de salada de quiabo e tomate, uma boa opção de acompanhamento leve para dias quentes.",
    categoria: "receitas",
    categoriaNome: "Receitas",
    url: "salada-de-quiabo-e-tomate.html",
    tempoLeitura: "6 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Como ganhar peso de forma saudável: guia completo",
    resumo: "Guia completo com estratégias práticas para ganhar peso de forma saudável, com foco em alimentação e hábitos sustentáveis.",
    categoria: "ganhar-peso",
    categoriaNome: "Ganhar Peso",
    url: "como-ganhar-peso-de-forma-saudavel-guia-completo.html",
    tempoLeitura: "10 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Alimentos calóricos e saudáveis para quem quer engordar",
    resumo: "Lista de alimentos calóricos e nutritivos que podem ajudar quem quer ganhar peso de forma saudável.",
    categoria: "ganhar-peso",
    categoriaNome: "Ganhar Peso",
    url: "alimentos-caloricos-e-saudaveis-para-engordar.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Erros comuns de quem tenta ganhar peso e não consegue",
    resumo: "Conheça os erros mais comuns que impedem o ganho de peso saudável e como corrigi-los.",
    categoria: "ganhar-peso",
    categoriaNome: "Ganhar Peso",
    url: "erros-comuns-tentar-ganhar-peso.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Como montar um plano alimentar para ganho de massa muscular",
    resumo: "Passo a passo simples para montar um plano alimentar direcionado ao ganho de massa muscular, combinando alimentação e exercício.",
    categoria: "ganhar-peso",
    categoriaNome: "Ganhar Peso",
    url: "plano-alimentar-ganho-de-massa-muscular.html",
    tempoLeitura: "9 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Como emagrecer de forma saudável e duradoura",
    resumo: "Guia com estratégias realistas e sustentáveis para emagrecer de forma saudável, sem dietas radicais.",
    categoria: "emagrecer",
    categoriaNome: "Emagrecer",
    url: "como-emagrecer-de-forma-saudavel-e-duradoura.html",
    tempoLeitura: "10 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Mitos e verdades sobre dietas de emagrecimento",
    resumo: "Esclarecimento sobre mitos comuns relacionados a dietas de emagrecimento, com informações responsáveis e realistas.",
    categoria: "emagrecer",
    categoriaNome: "Emagrecer",
    url: "mitos-e-verdades-sobre-dietas-de-emagrecimento.html",
    tempoLeitura: "9 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Como controlar a fome durante o processo de emagrecimento",
    resumo: "Estratégias práticas para lidar com a fome durante um processo de emagrecimento, sem sofrimento excessivo.",
    categoria: "emagrecer",
    categoriaNome: "Emagrecer",
    url: "controlar-a-fome-durante-emagrecimento.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Emagrecimento sem passar fome: estratégias práticas",
    resumo: "Estratégias práticas para emagrecer sem passar fome, priorizando alimentos que trazem saciedade.",
    categoria: "emagrecer",
    categoriaNome: "Emagrecer",
    url: "emagrecimento-sem-passar-fome.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Exercícios para iniciantes: como começar em casa",
    resumo: "Guia para quem quer começar a exercitar-se em casa, sem equipamento, com segurança e progressão gradual.",
    categoria: "exercicios",
    categoriaNome: "Exercícios",
    url: "exercicios-para-iniciantes-como-comecar-em-casa.html",
    tempoLeitura: "9 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Caminhada: benefícios e como criar o hábito",
    resumo: "Conheça os benefícios da caminhada regular e como transformá-la num hábito consistente no dia a dia.",
    categoria: "exercicios",
    categoriaNome: "Exercícios",
    url: "caminhada-beneficios-e-como-criar-o-habito.html",
    tempoLeitura: "7 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Treino de força para iniciantes: guia básico",
    resumo: "Introdução ao treino de força para quem está a começar, com princípios básicos de segurança e progressão.",
    categoria: "exercicios",
    categoriaNome: "Exercícios",
    url: "treino-de-forca-para-iniciantes.html",
    tempoLeitura: "9 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Como manter a motivação para se exercitar",
    resumo: "Estratégias práticas para manter a motivação e a consistência num programa de exercícios ao longo do tempo.",
    categoria: "exercicios",
    categoriaNome: "Exercícios",
    url: "como-manter-a-motivacao-para-se-exercitar.html",
    tempoLeitura: "7 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Vitamina C: benefícios, fontes e cuidados",
    resumo: "Conheça os benefícios da vitamina C, as suas principais fontes alimentares e cuidados a ter.",
    categoria: "vitaminas",
    categoriaNome: "Vitaminas",
    url: "vitamina-c-beneficios-fontes-e-cuidados.html",
    tempoLeitura: "7 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Vitamina D: por que é importante e como obter",
    resumo: "Entenda a importância da vitamina D para a saúde óssea e imunitária, e como garantir níveis adequados.",
    categoria: "vitaminas",
    categoriaNome: "Vitaminas",
    url: "vitamina-d-por-que-e-importante.html",
    tempoLeitura: "7 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Complexo B: energia e funcionamento do sistema nervoso",
    resumo: "Entenda o papel das vitaminas do complexo B na energia e no sistema nervoso, e onde encontrá-las na alimentação.",
    categoria: "vitaminas",
    categoriaNome: "Vitaminas",
    url: "complexo-b-energia-e-sistema-nervoso.html",
    tempoLeitura: "7 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Ferro na alimentação: prevenção da anemia",
    resumo: "Entenda a importância do ferro na alimentação para a prevenção da anemia e quais alimentos são boas fontes.",
    categoria: "vitaminas",
    categoriaNome: "Vitaminas",
    url: "ferro-na-alimentacao-prevencao-da-anemia.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Hidratação: quanta água deve beber por dia",
    resumo: "Entenda a importância da hidratação, quanta água beber por dia e sinais de desidratação a que deve prestar atenção.",
    categoria: "saude",
    categoriaNome: "Saúde",
    url: "hidratacao-quanta-agua-beber-por-dia.html",
    tempoLeitura: "7 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Sono de qualidade: por que é essencial para a saúde",
    resumo: "Entenda por que o sono de qualidade é essencial para a saúde física e mental, e como melhorar os seus hábitos de sono.",
    categoria: "saude",
    categoriaNome: "Saúde",
    url: "sono-de-qualidade-por-que-e-essencial.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Pressão arterial: como cuidar da sua saúde cardiovascular",
    resumo: "Entenda o que é a pressão arterial, por que é importante monitorizá-la e hábitos que ajudam a cuidar da saúde cardiovascular.",
    categoria: "saude",
    categoriaNome: "Saúde",
    url: "pressao-arterial-saude-cardiovascular.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Como gerir o stress no dia a dia",
    resumo: "Estratégias práticas para gerir o stress do dia a dia e proteger a saúde física e mental.",
    categoria: "bem-estar",
    categoriaNome: "Bem-estar",
    url: "como-gerir-o-stress-no-dia-a-dia.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Saúde mental: sinais de alerta e quando procurar ajuda",
    resumo: "Conheça alguns sinais de alerta relacionados à saúde mental e saiba quando é importante procurar apoio profissional.",
    categoria: "bem-estar",
    categoriaNome: "Bem-estar",
    url: "saude-mental-sinais-de-alerta.html",
    tempoLeitura: "8 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
  {
    titulo: "Rotina matinal saudável: como começar bem o dia",
    resumo: "Ideias práticas para montar uma rotina matinal saudável que ajuda a começar o dia com mais energia e foco.",
    categoria: "bem-estar",
    categoriaNome: "Bem-estar",
    url: "rotina-matinal-saudavel.html",
    tempoLeitura: "7 min",
    data: "2026-07-09",
    autor: "Equipa Vida Saudável Angola"
  },
];
