/* ==========================================================================
   VIDA SAUDÁVEL ANGOLA — main.js
   JavaScript puro, sem dependências. Corre em todas as páginas.
   ========================================================================== */
(function () {
  "use strict";

  // ---- CONFIGURAÇÃO -------------------------------------------------------
  // Troque pelo número real do WhatsApp do site (formato internacional, sem +).
  var CONFIG = {
    whatsappNumero: "244945161238",
    whatsappMensagem: "Olá! Visitei o site Vida Saudável Angola e gostaria de partilhar a minha opinião para ajudar a melhorar.",
    caminhoPartials: calcularCaminhoBase() + "partials/",
  };

  // Calcula quantos níveis de pasta a página atual está da raiz,
  // para que os partials e links funcionem em qualquer subpasta.
  function calcularCaminhoBase() {
    var profundidade = document.documentElement.getAttribute("data-profundidade");
    var n = profundidade ? parseInt(profundidade, 10) : 0;
    return "../".repeat(n);
  }
  var BASE = calcularCaminhoBase();

  // ---- CARREGAR PARTIALS (header/footer) ----------------------------------
  function carregarParcial(seletorDestino, ficheiro, aoTerminar) {
    var alvo = document.querySelector(seletorDestino);
    if (!alvo) return;
    fetch(CONFIG.caminhoPartials + ficheiro)
      .then(function (r) {
        if (!r.ok) throw new Error("Falha ao carregar " + ficheiro);
        return r.text();
      })
      .then(function (html) {
        html = html.replace(/{{BASE}}/g, BASE);
        alvo.innerHTML = html;
        if (aoTerminar) aoTerminar();
      })
      .catch(function (erro) {
        console.warn("[Vida Saudável Angola]", erro.message);
      });
  }

  document.addEventListener("DOMContentLoaded", function () {
    carregarParcial("#cabecalho-app", "header.html", inicializarCabecalho);
    carregarParcial("#rodape-app", "footer.html", null);
    inicializarTema();
    inicializarBotoesFlutuantes();
    inicializarFadeIn();
    inicializarServiceWorker();
  });

  // ---- CABEÇALHO / MENU LATERAL -------------------------------------------
  function inicializarCabecalho() {
    var body = document.body;
    var botaoMenu = document.querySelector(".botao-menu");
    var botaoFechar = document.querySelector(".menu-lateral .fechar");
    var fundoMenu = document.querySelector(".fundo-menu");
    var botaoTema = document.querySelector(".botao-tema");

    function abrirMenu() {
      body.classList.add("menu-aberto");
      botaoMenu.setAttribute("aria-expanded", "true");
    }
    function fecharMenu() {
      body.classList.remove("menu-aberto");
      botaoMenu.setAttribute("aria-expanded", "false");
    }
    if (botaoMenu) botaoMenu.addEventListener("click", function () {
      body.classList.contains("menu-aberto") ? fecharMenu() : abrirMenu();
    });
    if (botaoFechar) botaoFechar.addEventListener("click", fecharMenu);
    if (fundoMenu) fundoMenu.addEventListener("click", fecharMenu);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") fecharMenu();
    });

    if (botaoTema) botaoTema.addEventListener("click", alternarTema);

    var formPesquisa = document.querySelector(".pesquisa-menu");
    if (formPesquisa) {
      formPesquisa.addEventListener("submit", function (e) {
        e.preventDefault();
        var termo = formPesquisa.querySelector("input").value.trim();
        if (termo) {
          window.location.href = BASE + "blog/index.html?q=" + encodeURIComponent(termo);
        }
      });
    }
  }

  // ---- TEMA CLARO / ESCURO -------------------------------------------------
  function inicializarTema() {
    var salvo = localStorage.getItem("vsa-tema");
    var preferido = salvo || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "escuro" : "claro");
    document.documentElement.setAttribute("data-theme", preferido);
  }
  function alternarTema() {
    var atual = document.documentElement.getAttribute("data-theme");
    var novo = atual === "escuro" ? "claro" : "escuro";
    document.documentElement.setAttribute("data-theme", novo);
    localStorage.setItem("vsa-tema", novo);
  }

  // ---- BOTÕES FLUTUANTES (WhatsApp + Voltar ao topo) -----------------------
  function inicializarBotoesFlutuantes() {
    var linkWhats = document.querySelector(".whatsapp-flutuante");
    if (linkWhats) {
      linkWhats.href = "https://wa.me/" + CONFIG.whatsappNumero + "?text=" + encodeURIComponent(CONFIG.whatsappMensagem);
    }
    var botaoTopo = document.querySelector(".topo-flutuante");
    if (botaoTopo) {
      window.addEventListener("scroll", function () {
        botaoTopo.classList.toggle("visivel", window.scrollY > 500);
      }, { passive: true });
      botaoTopo.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    }
  }

  // ---- ANIMAÇÃO SUAVE AO ENTRAR NO ECRÃ -------------------------------------
  function inicializarFadeIn() {
    var alvos = document.querySelectorAll(".fade-in");
    if (!("IntersectionObserver" in window) || !alvos.length) {
      alvos.forEach(function (el) { el.classList.add("mostrar"); });
      return;
    }
    var observador = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (entrada) {
        if (entrada.isIntersecting) {
          entrada.target.classList.add("mostrar");
          observador.unobserve(entrada.target);
        }
      });
    }, { threshold: 0.12 });
    alvos.forEach(function (el) { observador.observe(el); });
  }

  // ---- PWA: REGISTAR SERVICE WORKER -----------------------------------------
  function inicializarServiceWorker() {
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", function () {
        navigator.serviceWorker.register(BASE + "sw.js").catch(function (erro) {
          console.warn("[Vida Saudável Angola] Service worker não registado:", erro.message);
        });
      });
    }
  }
})();
