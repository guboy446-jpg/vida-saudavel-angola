(function () {
  "use strict";

  function mostrarResultado(id, html) {
    var el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = html;
    el.classList.add("visivel");
  }

  // ---- IMC ----
  var btnImc = document.getElementById("imc-calcular");
  if (btnImc) btnImc.addEventListener("click", function () {
    var peso = parseFloat(document.getElementById("imc-peso").value);
    var alturaCm = parseFloat(document.getElementById("imc-altura").value);
    if (!peso || !alturaCm) { mostrarResultado("imc-resultado", "Preencha o peso e a altura."); return; }
    var alturaM = alturaCm / 100;
    var imc = peso / (alturaM * alturaM);
    var classificacao;
    if (imc < 18.5) classificacao = "abaixo do peso";
    else if (imc < 25) classificacao = "peso normal";
    else if (imc < 30) classificacao = "excesso de peso";
    else classificacao = "obesidade";
    mostrarResultado("imc-resultado", "O seu IMC é <strong>" + imc.toFixed(1) + "</strong> — categoria: " + classificacao + ".");
  });

  // ---- Calorias (Mifflin-St Jeor) ----
  var btnCal = document.getElementById("cal-calcular");
  if (btnCal) btnCal.addEventListener("click", function () {
    var sexo = document.getElementById("cal-sexo").value;
    var idade = parseFloat(document.getElementById("cal-idade").value);
    var peso = parseFloat(document.getElementById("cal-peso").value);
    var altura = parseFloat(document.getElementById("cal-altura").value);
    var atividade = parseFloat(document.getElementById("cal-atividade").value);
    if (!idade || !peso || !altura) { mostrarResultado("cal-resultado", "Preencha todos os campos."); return; }
    var tmb = sexo === "homem"
      ? 10 * peso + 6.25 * altura - 5 * idade + 5
      : 10 * peso + 6.25 * altura - 5 * idade - 161;
    var manutencao = Math.round(tmb * atividade);
    mostrarResultado("cal-resultado",
      "Para manter o peso atual: cerca de <strong>" + manutencao + " kcal/dia</strong>.<br>" +
      "Para emagrecer com segurança: aproximadamente " + Math.round(manutencao - 400) + " kcal/dia.<br>" +
      "Para ganhar peso de forma gradual: aproximadamente " + Math.round(manutencao + 400) + " kcal/dia.");
  });

  // ---- Água ----
  var btnAgua = document.getElementById("agua-calcular");
  if (btnAgua) btnAgua.addEventListener("click", function () {
    var peso = parseFloat(document.getElementById("agua-peso").value);
    if (!peso) { mostrarResultado("agua-resultado", "Preencha o peso."); return; }
    var mililitros = peso * 35;
    mostrarResultado("agua-resultado", "Recomendação aproximada: <strong>" + (mililitros / 1000).toFixed(1) + " litros por dia</strong> (cerca de " + Math.round(mililitros / 250) + " copos de 250 ml).");
  });

  // ---- Peso ideal (fórmula de Devine) ----
  var btnPeso = document.getElementById("peso-calcular");
  if (btnPeso) btnPeso.addEventListener("click", function () {
    var sexo = document.getElementById("peso-sexo").value;
    var alturaCm = parseFloat(document.getElementById("peso-altura").value);
    if (!alturaCm) { mostrarResultado("peso-resultado", "Preencha a altura."); return; }
    var alturaPol = alturaCm / 2.54;
    var polegadasAcima5pes = Math.max(alturaPol - 60, 0);
    var pesoIdeal = sexo === "homem"
      ? 50 + 2.3 * polegadasAcima5pes
      : 45.5 + 2.3 * polegadasAcima5pes;
    mostrarResultado("peso-resultado", "Estimativa: <strong>" + pesoIdeal.toFixed(1) + " kg</strong>.");
  });
})();
