/* Vida Saudável Angola — Service Worker
   Estratégia: cache-first para ficheiros estáticos, network-first para páginas HTML.
   Atualize CACHE_VERSAO sempre que publicar alterações grandes ao CSS/JS. */

const CACHE_VERSAO = "vsa-v1";
const FICHEIROS_ESSENCIAIS = [
  "/",
  "/index.html",
  "/assets/css/style.css",
  "/assets/js/main.js",
  "/manifest.json",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/404.html"
];

self.addEventListener("install", (evento) => {
  evento.waitUntil(
    caches.open(CACHE_VERSAO).then((cache) => cache.addAll(FICHEIROS_ESSENCIAIS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (evento) => {
  evento.waitUntil(
    caches.keys().then((chaves) =>
      Promise.all(
        chaves
          .filter((chave) => chave !== CACHE_VERSAO)
          .map((chave) => caches.delete(chave))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (evento) => {
  const pedido = evento.request;
  if (pedido.method !== "GET") return;

  const ehPagina = pedido.mode === "navigate";

  if (ehPagina) {
    // Network-first: conteúdo de artigos deve estar sempre atualizado.
    evento.respondWith(
      fetch(pedido)
        .then((resposta) => {
          const copia = resposta.clone();
          caches.open(CACHE_VERSAO).then((cache) => cache.put(pedido, copia));
          return resposta;
        })
        .catch(() =>
          caches.match(pedido).then((res) => res || caches.match("/404.html"))
        )
    );
    return;
  }

  // Cache-first: CSS, JS, imagens e ícones.
  evento.respondWith(
    caches.match(pedido).then((emCache) => {
      if (emCache) return emCache;
      return fetch(pedido).then((resposta) => {
        const copia = resposta.clone();
        caches.open(CACHE_VERSAO).then((cache) => cache.put(pedido, copia));
        return resposta;
      });
    })
  );
});
